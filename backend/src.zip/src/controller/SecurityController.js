const router = require("express").Router();
const { User } = require("../models")
const bcrypt = require("bcrypt")

export default class SecurityController{
    
}
class SecurityController {
    
    static registerUser = (async (req,res)=>{
        try{
            //genarete new password
            const salt = await bcrypt.genSalt(10);
            const hashedPassword = await bcrypt.hash(req.body.password, salt);
            
            // create new user
            const newUser = {
                user: req.body.user,
                password: hashedPassword
            };
            // create a new profile
            // const newProfile = {
            //     name:req.body.nome,
            // }
            //save user and response
            const user = await User.create(newUser);
            // const profile = await Profile.create(newProfile);
            res.status(200).json(user);
            res.status(200).json(profile);
        }catch(err){
            console.log(err)
            res.status(500).json(err)
        }
    });

}


