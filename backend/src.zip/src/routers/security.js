const router = require("express").Router();
const { User } = require("../models");
import SecurityController from "../controller/SecurityController"; 
const bcrypt = require("bcrypt");


//REGISTER
router
    .post("/register",SecurityController.);

s
    //LOGIN
    router.post("/login", async(req,res)=>{
        try{    
            const user = await User.findOne({user:req.body.user});
            !user && res.status(404).send("User not found")

            const validPassword = await bcrypt.compare(req.body.password, user.password)
            !validPassword && res.status(400).json("Wrong Password")

            res.status(200).json(user)
        }catch(err){
            res.status(500).json(err)
        }

    
       // UPDATE USER WITH PROFILE

    //     router.put("/:id", async(req,res)=>{
    //         if(req.body.profileId == req.params.id || req.body.isAdmin){
    //                 try{
    //                     const salt = await bcrypt.genSalt(10);
    //                     req.body.password = await bcrypt.hash(req.body.password, salt);
    //                 }catch(err){
    //                     return res.status(500).json(err);
    //                 }
    //             try{
    //                 const profile = await User.findByIdAndUpdate(req.params.id,{
    //                     $set: req.body,
    //                 });
    //                 res.status(200).json("account updated")
    //             }catch(err){
    //                 return res.status(500).json(err);
    //             }
    //         }else{
    //             return res.status(403).json("cant update")
    //         }
    //     });

    });
export default router;
    
    